<?php
// carte.class.php
class Carte
{
	private $id;
	private $name;
	private $type;
	private $price_in;
	private $price_delivery;
	private $availability;
	private $photo;

	public function display()
	{
		
	}
	public function getShortName()
	{
		return substr($this->name, 0, 10).'...';
	}
	public function displayInTab()
	{
		require('test.html');
	}
	public function displayFull()
	{

	}
	public function displayShort()
	{

	}
}

// views.class.php
class Views
{
	public function displayHeader()
	{

	}
	public function displayContent()
	{

	}
}





$mysqli = mysqli_connect("localhost","root","troiswa","resto");
$res = mysqli_query($mysqli, "SELECT * FROM carte");
$view->displayCarte($res);


echo "<table border=1>";
while ($obj = mysqli_fetch_object($res, 'Carte'))
{
	//echo $obj->getShortName().'<br />';
	$obj->displayInTab();
}
echo "</table>";
?>